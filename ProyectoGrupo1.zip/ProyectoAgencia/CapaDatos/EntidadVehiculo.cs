﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CapaDatos
{
    class EntidadVehiculo
    {
        public int id_vehiculo { get; set; }
        public int placa { get; set; }

        public string marca { get; set; }

        public int anno { get; set; }

        public string Modelo { get; set; }

        public int Cilindraje { get; set; }

        public string color { get; set; }

        public string Tipo_Combustible { get; set; }








    }
}
