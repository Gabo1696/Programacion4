﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CapaDatos
{
    class EntidadIngreso
    {
      public int  id_Cliente { get; set; }
public string usuario { get; set; }
public string contraseña { get; set; } 
    }
}
